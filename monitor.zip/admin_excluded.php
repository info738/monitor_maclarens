<?php
// admin_excluded.php
session_start();
// if (!isset($_SESSION['logged_in'])) { exit('Nepřihlášen.'); }

ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require 'db.php';

$productsFile = 'products.json';
$excludedFile = 'excluded_items.json';

// 0) Import již dříve vyloučených položek z excluded_items.json do DB,
// pokud je tabulka excluded_products prázdná.
$stmt = $db->query("SELECT COUNT(*) FROM excluded_products");
$count = $stmt->fetchColumn();
if ($count == 0 && file_exists($excludedFile)) {
    $json = file_get_contents($excludedFile);
    $excludedFromJson = json_decode($json, true);
    if (is_array($excludedFromJson)) {
        $stmtInsert = $db->prepare("INSERT INTO excluded_products (product_id) VALUES (:product_id)");
        foreach ($excludedFromJson as $pid) {
            $stmtInsert->execute([':product_id' => $pid]);
        }
    }
}

// 1) Načtení produktů z products.json (očekáváme pole produktů)
if (!file_exists($productsFile)) {
    die("products.json neexistuje. Spusťte fetch_products.php nebo jiný skript.");
}
$productsData = json_decode(file_get_contents($productsFile), true);
if (!is_array($productsData)) {
    die("Neplatný formát products.json (není pole).");
}

// 2) Načtení aktuálního seznamu vyloučených produktů z DB
$stmt = $db->query("SELECT product_id FROM excluded_products");
$excludedData = $stmt->fetchAll(PDO::FETCH_COLUMN);

// 3) Zpracování formuláře – aktualizace seznamu vyloučených produktů
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Očekáváme, že formulář vrací pole 'excluded' obsahující produktová ID
    $newExcluded = $_POST['excluded'] ?? [];
    // Vymažeme celý stávající seznam
    $db->exec("DELETE FROM excluded_products");
    // Vložíme nová vyloučená ID
    $stmtInsert = $db->prepare("INSERT INTO excluded_products (product_id) VALUES (:product_id)");
    foreach ($newExcluded as $pid) {
        $stmtInsert->execute([':product_id' => $pid]);
    }
    $excludedData = $newExcluded;
    echo "<p style='padding:10px; background:#cfc;'>Uloženo! (".count($excludedData)." vyloučených položek)</p>";
}

// 4) Heuristika pro klíčová slova – např. pro nápoje
$beverageKeywords = [
    'pivo','beer','kofola','cola','cider','juice','tonic','vodka','rum','gin','mojito','mai-tai','tequila',
    'cuba libre','spritz','wine','vino','voda','rajec','sprite','f.h. prager','sierra nevada','desperados',
    // Další klíčová slova…
];

// 5) Rozdělení produktů – nápoje vs. ostatní
$beverageList = [];
$othersList   = [];
foreach ($productsData as $p) {
    $pname = $p['name'] ?? '';
    $pid   = $p['id'] ?? '';
    if (!$pname || !$pid) continue;
    $maybeBev = false;
    foreach ($beverageKeywords as $kw) {
        if (stripos($pname, $kw) !== false) {
            $maybeBev = true;
            break;
        }
    }
    if ($maybeBev) {
        $beverageList[] = $p;
    } else {
        $othersList[] = $p;
    }
}
usort($beverageList, function($a,$b){ return strcmp($a['name']??'', $b['name']??''); });
usort($othersList, function($a,$b){ return strcmp($a['name']??'', $b['name']??''); });
$finalList = array_merge($beverageList, $othersList);
?>
<!DOCTYPE html>
<html lang="cs">
<head>
  <meta charset="UTF-8">
  <title>Administrace vyloučených položek</title>
  <style>
    body {
      margin:0; padding:20px; font-family:Arial,sans-serif; background:#f0f0f0;
    }
    .top-menu {
      display:flex; gap:15px; margin-bottom:20px;
      background:#ddd; padding:10px; border-radius:8px;
      align-items:center;
    }
    .top-menu a {
      text-decoration:none; padding:6px 12px; background:#fff;
      border-radius:4px; color:#333; border:1px solid #ccc;
      font-size:13px;
    }
    .top-menu a:hover {
      background:#e0e0e0;
    }
    h1 { margin-top:0; }
    .search-row {
      margin-bottom:15px;
    }
    .search-row input {
      padding:6px; font-size:14px; width:300px; border-radius:4px; border:1px solid #ccc;
    }
    .grid-container {
      display:grid;
      grid-template-columns: repeat(auto-fill, minmax(220px,1fr));
      gap:16px;
    }
    .product-box {
      background:#fff; border-radius:8px; 
      padding:12px; box-shadow:0 4px 10px rgba(0,0,0,0.1);
      cursor:pointer; transition: background 0.2s, border 0.2s;
      border:2px solid transparent;
      display:flex; flex-direction:column;
      justify-content:space-between;
    }
    .product-box.excluded {
      background:#ffe5e5;
      border:2px solid #f44;
    }
    .product-name {
      font-size:14px; font-weight:600; margin:5px 0;
    }
    .product-id {
      font-size:11px; color:#777; margin-bottom:8px;
    }
    .tag-beverage {
      display:inline-block;
      background:#ffeb3b; color:#333; padding:2px 6px;
      margin-left:5px; font-size:11px; border-radius:4px; font-weight:bold;
    }
    .btn-save {
      margin-top:20px; padding:12px 20px; font-size:14px; border:none; border-radius:6px;
      background:#007bff; color:#fff; cursor:pointer;
    }
    .btn-save:hover {
      background:#0056b3;
    }
    .info-box {
      background:#eee; padding:10px; border-radius:4px; font-size:12px; color:#444;
      margin-bottom:15px;
    }
    .checkbox-hidden {
      display:none;
    }
    .hidden {
      display:none!important;
    }
  </style>
</head>
<body>

<div class="top-menu">
  <a href="index.php">Dashboard</a>
  <a href="kitchen.php">Kuchyň</a>
  <a href="bar.php">Bar</a>
  <a href="fetch_products.php">Stáhnout aktuální položky</a>
</div>

<h1>Administrace vyloučených položek</h1>

<div class="info-box">
  Zaškrtnuté produkty se nebudou zobrazovat v kuchyni.<br>
  Klikni na box pro označení/odznačení.
</div>

<form method="POST">
  <div class="search-row">
    <input type="text" id="searchInput" placeholder="Vyhledat položku..." onkeyup="filterBoxes()">
  </div>

  <div class="grid-container" id="productsContainer">
    <?php
    foreach ($finalList as $prod) {
        $pname = $prod['name'] ?? '';
        $pid   = $prod['id'] ?? '';
        if (!$pname || !$pid) continue;

        $isExcluded = in_array($pid, $excludedData, true);
        $maybeBeverage = in_array($prod, $beverageList, true);

        // Unikátní ID pro HTML prvek
        $htmlId = 'chk_'.md5($pid);
        $boxClass = 'product-box'.($isExcluded ? ' excluded' : '');

        echo "<label class='$boxClass' for='".htmlspecialchars($htmlId)."' data-boxid='".htmlspecialchars($htmlId)."' data-name='".strtolower($pname)."'>";
            echo "<div>";
                echo "<div class='product-name'>".htmlspecialchars($pname);
                if ($maybeBeverage) {
                    echo "<span class='tag-beverage'>Nápoj?</span>";
                }
                echo "</div>";
                echo "<div class='product-id'>ID: ".htmlspecialchars($pid)."</div>";
            echo "</div>";
            $checkedAttr = $isExcluded ? 'checked' : '';
            echo "<input type='checkbox' class='checkbox-hidden' id='".htmlspecialchars($htmlId)."' name='excluded[]' value='".htmlspecialchars($pid)."' $checkedAttr>";
        echo "</label>";
    }
    ?>
  </div>

  <button type="submit" class="btn-save">Uložit změny</button>
</form>

<script>
// Přidání listenerů pro změnu checkboxu – zabarvení boxu
document.addEventListener('DOMContentLoaded', function(){
  const boxes = document.querySelectorAll('.product-box');
  boxes.forEach(box => {
    const htmlId = box.getAttribute('data-boxid');
    const checkbox = document.getElementById(htmlId);
    checkbox.addEventListener('change', function(){
      if (checkbox.checked) {
        box.classList.add('excluded');
      } else {
        box.classList.remove('excluded');
      }
    });
  });
});

// Live-search funkce
function filterBoxes() {
  let input = document.getElementById('searchInput');
  let filter = input.value.toLowerCase();
  let container = document.getElementById('productsContainer');
  let boxes = container.querySelectorAll('.product-box');

  boxes.forEach(box => {
    let productName = box.dataset.name || '';
    if (productName.indexOf(filter) > -1) {
      box.classList.remove('hidden');
    } else {
      box.classList.add('hidden');
    }
  });
}
</script>
</body>
</html>
