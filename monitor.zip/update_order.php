<?php
// update_order.php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
require 'db.php';

$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['orderId'])) {
    echo json_encode(['error'=>'Chybí orderId']);
    exit;
}
$orderId = $input['orderId'];
$action = $input['action'] ?? '';

if ($action === 'passCompleted') {
    // U objednávky změníme všechny položky se stavem completed na passed
    $sql = "UPDATE order_items SET kitchen_status = 'passed' WHERE order_id = ? AND kitchen_status = 'completed'";
    $stmt = $db->prepare($sql);
    $result = $stmt->execute([$orderId]);
    if ($result) {
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['error'=>'Nepodařilo se aktualizovat objednávku']);
    }
    exit;
}

echo json_encode(['error'=>'Neznámá akce']);
?>
