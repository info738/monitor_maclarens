<?php
// kitchen.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'db.php';
date_default_timezone_set('Europe/Prague');
?>
<!DOCTYPE html>
<html lang="cs">
<head>
<meta charset="UTF-8">
<title>Kuchyňský monitor</title>
<meta http-equiv="refresh" content="30" />
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<style>
/* Stylování dle původního designu */
body {
  margin:0; padding:20px; font-family:'Roboto',sans-serif; background:#f1f1f1;
}
.top-menu {
  display:flex; gap:15px; margin-bottom:20px;
  background:#ddd; padding:10px; border-radius:8px;
  align-items:center;
}
.top-menu a {
  text-decoration:none; padding:6px 12px; background:#fff;
  border-radius:4px; color:#333; border:1px solid #ccc;
  font-size:13px;
}
.top-menu a:hover {
  background:#e0e0e0;
}
h2 {
  font-weight:700; margin-bottom:20px;
}
.hr-line {
  margin:40px 0; border:0; border-top:2px dashed #ccc;
}
.orders-container {
  display:flex; flex-wrap:wrap; gap:20px; align-items:flex-start;
}
.order-box {
  background:#fff; border-radius:8px; width:300px;
  box-shadow:0 4px 10px rgba(0,0,0,0.06);
  display:flex; flex-direction:column; overflow:hidden; height:auto;
}
.order-header {
  padding:6px 16px; border-bottom:1px solid #ddd;
  background:#333; color:#fff; border-radius:10px 10px 0 0; text-align:center;
}
.order-header h3 {
  margin:0; font-size:13px; font-weight:500;
}
.order-body {
  padding:16px;
}
.order-meta {
  font-size:12px; color:#666; margin-bottom:10px;
}
.order-items {
  list-style:none; padding:0; margin:0;
}
.order-item {
  background:#fafafa; border:1px solid #eee; border-radius:6px;
  padding:8px 10px; margin-bottom:10px;
  display:flex; flex-direction:column;
}
.order-item .item-title {
  font-size:14px; font-weight:700; margin:0 0 4px 0;
}
.buttons-row {
  margin-top:8px; display:flex; gap:6px;
}
.btn {
  padding:5px 10px; font-size:12px; border:none; border-radius:4px;
  cursor:pointer; transition:background 0.15s;
}
.btn:hover { opacity:0.9; }
.btn-primary { background:#007bff; color:#fff; }
.btn-complete { background:#28a745; color:#fff; }
.status-new { border-left:4px solid #ef5350; }
.status-in-progress { border-left:4px solid #ffa726; }
.status-reordered { border-left:4px solid #8a2be2; background:#f8ecff; }
.delivery-logo { height:20px; vertical-align:middle; margin-right:5px; }
.subitem-line {
  font-size:12px; color:#000; margin-top:3px; margin-left:10px;
  border:1px solid #dfdfdf; padding:5px 10px; background-color:#fff;
  border-radius:5px; width:71%; font-weight:bold;
}
.poznamka { font-size:12px; font-weight:bold; }
#stul {
  background-color:#000;
  font-size:16px;
  color:#fff;
  padding:5px 10px;
  border-radius:5px;
  float:right;
}
</style>
</head>
<body>
<div class="top-menu">
  <a href="dashboard.php">Dashboard</a>
  <a href="bar.php">Bar</a>
  <a href="admin_excluded.php">Vyloučené položky</a>
</div>
<?php
// Dotaz pro aktivní položky – filtrujeme tak, aby se nezobrazovaly položky s product_id, jež jsou uvedeny v excluded_products.
$sqlActive = "SELECT oi.*, o.created, o.table_name, o.delivery_service, o.delivery_note
              FROM order_items oi
              JOIN orders o ON oi.order_id = o.id
              WHERE oi.kitchen_status IN ('new','in-progress','reordered')
                AND (oi.product_id IS NULL OR oi.product_id NOT IN (SELECT product_id FROM excluded_products))
              ORDER BY o.created ASC";
$stmt = $db->query($sqlActive);
$activeItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Dotaz pro dokončené položky (také aplikujeme filtr)
$sqlCompleted = "SELECT oi.*, o.created, o.table_name, o.delivery_service, o.delivery_note
                 FROM order_items oi
                 JOIN orders o ON oi.order_id = o.id
                 WHERE oi.kitchen_status = 'completed'
                   AND (oi.product_id IS NULL OR oi.product_id NOT IN (SELECT product_id FROM excluded_products))
                 ORDER BY o.created ASC";
$stmt = $db->query($sqlCompleted);
$completedItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Pro notifikaci – získáme ID položek, které mají shown = 0 (a nejsou vyloučené)
$sqlNewNotification = "SELECT id FROM order_items
                       WHERE kitchen_status IN ('new','in-progress','reordered')
                         AND shown = 0
                         AND (product_id IS NULL OR product_id NOT IN (SELECT product_id FROM excluded_products))";
$stmt = $db->query($sqlNewNotification);
$newOrderIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Aktualizace položek, které jsme již "notifikovali"
if (!empty($newOrderIds)) {
    $in = str_repeat('?,', count($newOrderIds) - 1) . '?';
    $sqlUpdate = "UPDATE order_items SET shown = 1 WHERE id IN ($in)";
    $stmtUpdate = $db->prepare($sqlUpdate);
    $stmtUpdate->execute($newOrderIds);
}
?>
<h2>Kuchyň - Aktivní</h2>
<div class="orders-container">
<?php
// Seskupíme aktivní položky podle objednávky
$activeOrders = [];
foreach ($activeItems as $item) {
    $orderId = $item['order_id'];
    $activeOrders[$orderId][] = $item;
}
foreach ($activeOrders as $orderId => $items) {
    $orderInfo = $items[0];
    echo "<div class='order-box'>";
    echo "<div class='order-header'><h3>Objednávka č. " . htmlspecialchars($orderId) . "</h3></div>";
    echo "<div class='order-body'>";
    if (!empty($orderInfo['table_name'])) {
        echo "<div id='stul'>Stůl: " . htmlspecialchars($orderInfo['table_name']) . "</div>";
    }
    if (!empty($orderInfo['delivery_service'])) {
        $service = strtolower($orderInfo['delivery_service']);
        echo "<div style='float:right;padding-top:3px;'>
              <img class='delivery-logo' src='logos/$service.png' alt='$service logo'>
              </div>";
    }
    echo "<div class='order-meta'>Vytvořeno: " . htmlspecialchars($orderInfo['created']) . "</div>";
    echo "<ul class='order-items'>";
    foreach ($items as $it) {
        $cssClass = '';
        $ks = $it['kitchen_status'];
        if ($ks==='new') $cssClass = 'status-new';
        if ($ks==='in-progress') $cssClass = 'status-in-progress';
        if ($ks==='reordered') $cssClass = 'status-reordered';
        echo "<li class='order-item $cssClass' data-itemid='".htmlspecialchars($it['id'])."'>";
        echo "<div class='item-title'>".htmlspecialchars($it['quantity'])." × ".htmlspecialchars($it['name'])."</div>";
        if (!empty($it['note'])) {
            echo "<div style='font-size:12px;color:#c00;font-weight:bold;margin-top:2px;'>".htmlspecialchars($it['note'])."</div>";
        }
        // Načteme podpoložky, pokud existují
        $sqlSub = "SELECT * FROM order_item_subitems WHERE order_item_id = ?";
        $stmtSub = $db->prepare($sqlSub);
        $stmtSub->execute([$it['id']]);
        $subitems = $stmtSub->fetchAll(PDO::FETCH_ASSOC);
        if ($subitems) {
            foreach ($subitems as $sub) {
                echo "<div class='subitem-line'>+ ".htmlspecialchars($sub['quantity'])." × ".htmlspecialchars($sub['name'])."</div>";
            }
        }
        echo "<div class='buttons-row'>";
        echo "<button class='btn btn-primary' onclick='changeItemStatus(\"in-progress\",\"".$it['id']."\")'>V přípravě</button>";
        if ($ks==='in-progress') {
            echo "<button class='btn btn-complete' onclick='changeItemStatus(\"completed\",\"".$it['id']."\")'>Dokončeno</button>";
        } else {
            echo "<button class='btn btn-complete' style='opacity:0.5;cursor:not-allowed' disabled>Dokončeno</button>";
        }
        echo "</div>";
        echo "</li>";
    }
    echo "</ul>";
    if (!empty($orderInfo['delivery_note'])) {
        echo "<span class='poznamka'>Poznámka:</span><hr>";
        echo "<div class='order-meta'>".htmlspecialchars($orderInfo['delivery_note'])."</div>";
    }
    echo "</div>";
    echo "</div>";
}
?>
</div>
<hr class="hr-line">
<h2>Kuchyň - Dokončené</h2>
<div class="orders-container gray-section">
<?php
// Seskupíme dokončené položky podle objednávky
$completedOrders = [];
foreach ($completedItems as $item) {
    $orderId = $item['order_id'];
    $completedOrders[$orderId][] = $item;
}
foreach ($completedOrders as $orderId => $items) {
    $orderInfo = $items[0];
    echo "<div class='order-box'>";
    echo "<div class='order-header'><h3>Objednávka č. " . htmlspecialchars($orderId) . "</h3></div>";
    echo "<div class='order-body'>";
    echo "<div class='order-meta'>Vytvořeno: " . htmlspecialchars($orderInfo['created']) . "</div>";
    echo "<ul class='order-items'>";
    foreach ($items as $it) {
        echo "<li class='order-item status-completed' data-itemid='".htmlspecialchars($it['id'])."'>";
        echo "<div class='item-title'>".htmlspecialchars($it['name'])." × ".htmlspecialchars($it['quantity'])."</div>";
        echo "<div class='buttons-row'>";
        echo "<button class='btn btn-primary' onclick='changeItemStatus(\"in-progress\",\"".$it['id']."\")'>Vrátit do přípravy</button>";
        echo "</div>";
        echo "</li>";
    }
    echo "</ul>";
    if (!empty($orderInfo['delivery_note'])) {
        echo "<div class='order-meta'>".htmlspecialchars($orderInfo['delivery_note'])."</div>";
    }
    echo "</div>";
    echo "</div>";
}
?>
</div>
<script>
function changeItemStatus(newStatus, itemId) {
  fetch('update_item.php', {
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ itemId: itemId, newStatus: newStatus })
  })
  .then(response => response.json())
  .then(data => {
    console.log(data);
    location.reload();
  })
  .catch(error => console.error(error));
}
</script>
</body>
</html>
